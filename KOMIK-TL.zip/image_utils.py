# image_utils.py
import os
import requests
import concurrent.futures
import numpy as np
import cv2 # Tambahkan ini di deretan import atas

from PIL import Image, ImageDraw, ImageFont

class ImageProcessor:
    @staticmethod
    def detect_colors(pil_img, box):
        # 1. Crop gambar sesuai bounding box (kotak teks)
        crop = pil_img.crop((
            max(0, int(box[0])), 
            max(0, int(box[1])), 
            min(pil_img.width, int(box[2])), 
            min(pil_img.height, int(box[3]))
        ))
        
        # 2. Ubah ke numpy array RGB
        img_np = np.array(crop.convert("RGB"))
        
        # Keamanan: Jika crop gagal atau terlalu kecil, pakai warna default hitam-putih
        if img_np.size == 0 or img_np.shape[0] < 3 or img_np.shape[1] < 3:
            return (0, 0, 0), (255, 255, 255)
            
        # 3. Ratakan piksel menjadi 2D array untuk K-Means
        pixels = img_np.reshape((-1, 3)).astype(np.float32)
        
        # 4. Terapkan K-Means Clustering dengan K=2 (Mencari 2 warna dominan)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
        K = 2
        
        try:
            _, labels, centers = cv2.kmeans(pixels, K, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
            
            # Ubah format hasil warna kembali ke integer
            centers = np.uint8(centers)
            
            # Hitung jumlah piksel untuk masing-masing kelompok warna
            counts = np.bincount(labels.flatten())
            
            # Logika: Di dalam bounding box OCR, area background/bubble biasanya
            # memakan ruang lebih banyak daripada garis huruf itu sendiri.
            # Jadi, warna dengan jumlah piksel terbanyak = Background/Stroke
            # Warna dengan jumlah piksel lebih sedikit = Teks
            bg_idx = np.argmax(counts)
            text_idx = 1 - bg_idx 
            
            text_color = tuple(int(c) for c in centers[text_idx])
            stroke_color = tuple(int(c) for c in centers[bg_idx])
            
            # Pastikan teks tetap kontras (jika warnanya ternyata sama/mirip, jadikan hitam putih)
            if sum(abs(t - b) for t, b in zip(text_color, stroke_color)) < 50:
                return (0, 0, 0), (255, 255, 255)
                
            return text_color, stroke_color
            
        except Exception as e:
            # Fallback jika perhitungan gagal
            return (0, 0, 0), (255, 255, 255)


class Typesetter:
    @staticmethod
    def apply_text(pil_img, text_blocks, font_path="arial.ttf", sfx_font_path="Dark Poestry.ttf"):
        
        # ==========================================
        # 0. FASE FILTERING (Menyaring Teks)
        # ==========================================
        valid_blocks = []
        for block in text_blocks:
            box = block['box']
            bh = box[3] - box[1]
            
            # Ambil teks asli untuk mengecek apakah ini 1 kata
            original_text = block.get('text', '')
            words = original_text.split()
            
            # Hitung estimasi ukuran font dan kemiringan
            font_size_est = int(block.get('orig_line_height', bh) * 0.9)
            angle = block.get('angle', 0.0)
            
            is_single_word = len(words) <= 1
            is_sfx = is_single_word and font_size_est > 50
            
            # Syarat 1: SFX (1 kata) yang miring dibiarkan aslinya
            # Angka 5 adalah batas toleransi kemiringan (derajat). Bisa kamu sesuaikan.
            if is_sfx and abs(angle) > 5:
                continue 
                
            # Syarat 2: Teks dengan ukuran raksasa dibiarkan aslinya
            # Angka 120 adalah batas ukuran font. Jika lebih dari 120px, skip.
            if font_size_est > 120:
                continue
                
            # Jika lolos syarat, masukkan ke daftar blok yang akan diproses
            valid_blocks.append(block)
            
        # Timpa text_blocks lama dengan yang sudah difilter
        text_blocks = valid_blocks

        # ==========================================
        # 1. FASE INPAINTING (Masking Teks via Canny Edge)
        # ==========================================
        img_np = np.array(pil_img.convert('RGB'))
        img_bgr = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        
        mask = np.zeros(img_bgr.shape[:2], dtype=np.uint8)
        
        for block in text_blocks:
            box = block['box']
            pad = 5
            x1, y1 = max(0, int(box[0]) - pad), max(0, int(box[1]) - pad)
            x2, y2 = min(img_bgr.shape[1], int(box[2]) + pad), min(img_bgr.shape[0], int(box[3]) + pad)
            
            if x2 - x1 < 5 or y2 - y1 < 5: continue
            
            roi_gray = gray[y1:y2, x1:x2]
            
            # 1. Cari garis tegas (huruf). Gradasi halus otomatis diabaikan!
            edges = cv2.Canny(roi_gray, 50, 150)
            
            # 2. Tebalkan garis tersebut agar outline (stroke) putih khas komik ikut tertutup
            kernel = np.ones((5,5), np.uint8)
            dilated = cv2.dilate(edges, kernel, iterations=2)
            
            # 3. Isi lubang di dalam huruf (seperti bagian dalam huruf O, A, P, dll)
            contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(dilated, contours, -1, 255, -1)
            
            # Tempelkan bentuk persis hurufnya ke mask utama
            mask[y1:y2, x1:x2] = cv2.bitwise_or(mask[y1:y2, x1:x2], dilated)
            
        # Eksekusi Inpainting (hanya akan menambal jalur huruf, background aman)
        inpainted_bgr = cv2.inpaint(img_bgr, mask, inpaintRadius=4, flags=cv2.INPAINT_NS)
        
        inpainted_rgb = cv2.cvtColor(inpainted_bgr, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(inpainted_rgb)

        # ==========================================
        # 2. FASE TYPESETTING (Menempel Teks Baru)
        # ==========================================
        for block in text_blocks:
            box = block['box']
            bw, bh = box[2] - box[0], box[3] - box[1]
            if bw < 6 or bh < 6: continue
            
            display_text = block.get('translated_text', block['text'])
            words = display_text.upper().split()
            is_single_word = len(words) <= 1
            
            max_font_limit = 150 
            font_size = int(block.get('orig_line_height', bh) * 0.9)
            font_size = max(10, min(max_font_limit, font_size)) 
            
            is_sfx = is_single_word and font_size > 50
            
            active_font_path = sfx_font_path if is_sfx and os.path.exists(sfx_font_path) else font_path
 
            total_height = 0
            line_height = 0
            lines = []
            
            while font_size > 8:
                font = ImageFont.truetype(active_font_path, font_size) if os.path.exists(active_font_path) else ImageFont.load_default()
                lines, current_line = [], []
                
                def get_tw(text):
                    bb = font.getbbox(text)
                    return bb[2] - bb[0] if bb else 0
                
                if is_single_word:
                    stroke_w = max(2, int(font_size * 0.08))
                    
                    word_width = get_tw(words[0]) + (stroke_w * 2) 
                    line_height = font.getbbox("A")[3] - font.getbbox("A")[1] + int(font_size * 0.45)
                    total_needed_h = line_height + (stroke_w * 2)
                    
                    if word_width <= (bw * 1.5) and total_needed_h <= (bh * 1.2):

                        lines = [words[0]]
                        total_height = line_height
                        break  
                    else:
                        font_size -= 2 
                        continue
                
                for word in words:
                    word_width = get_tw(word)
                    
                    if word_width > bw * 0.95:
                        if current_line:
                            lines.append(' '.join(current_line))
                            current_line = []
                            
                        temp_word = word
                        while temp_word:
                            for i in range(len(temp_word), 0, -1):
                                suffix = "-" if i < len(temp_word) else ""
                                part = temp_word[:i] + suffix
                                
                                if get_tw(part) <= bw * 0.95 or i == 1:
                                    if i == len(temp_word):
                                        current_line = [part]
                                    else:
                                        lines.append(part)
                                    temp_word = temp_word[i:]
                                    break
                    else:
                        test_line = ' '.join(current_line + [word]) if current_line else word
                        if get_tw(test_line) <= bw * 0.95:
                            current_line.append(word)
                        else:
                            if current_line:
                                lines.append(' '.join(current_line))
                            current_line = [word]
                            
                if current_line: 
                    lines.append(' '.join(current_line))
                
                line_height = font.getbbox("A")[3] - font.getbbox("A")[1] + int(font_size * 0.45)
                total_height = len(lines) * line_height
                
                if total_height <= bh * 0.95:
                    break
                font_size -= 1

            orig_bw = box[2] - box[0]

            pad_canvas = max(15, int(font_size * 0.3))
            canvas_w = orig_bw + (pad_canvas * 2)
            canvas_h = bh + (pad_canvas * 2)
            
            txt_canvas = Image.new('RGBA', (canvas_w, canvas_h), (0, 0, 0, 0))
            txt_draw = ImageDraw.Draw(txt_canvas)
            
            current_y = (canvas_h - total_height) // 2
            
            for line in lines:
                cw = font.getbbox(line)[2] - font.getbbox(line)[0]
                cx = (canvas_w - cw) // 2
                
                stroke_w = max(2, int(font_size * 0.08)) if is_single_word else max(1, int(font_size * 0.05))
                
                txt_draw.text(
                    (cx, current_y), 
                    line, 
                    font=font, 
                    fill=block['colors'][0], 
                    stroke_width=stroke_w, 
                    stroke_fill=block['colors'][1]
                )
                current_y += line_height
            
            angle = block.get('angle', 0.0)
            if abs(angle) > 3: 
                txt_canvas = txt_canvas.rotate(-angle, expand=True, resample=Image.BICUBIC)
            
            paste_x = box[0] + (orig_bw - txt_canvas.width) // 2
            paste_y = box[1] + (bh - txt_canvas.height) // 2
            
            pil_img.paste(txt_canvas, (paste_x, paste_y), txt_canvas)
                
        return pil_img

def download_image(url, save_path, chapter_url=""):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    if "bbato" in chapter_url:
        headers['Referer'] = "https://bbato.com/"
    elif "vymanga" in chapter_url:
        headers['Referer'] = "https://vymanga.com/"

    try:
        res = requests.get(url, headers=headers, stream=True, timeout=15)
        if res.status_code == 200:
            with open(save_path, 'wb') as f:
                for chunk in res.iter_content(1024): 
                    if chunk: 
                        f.write(chunk)
            
            if os.path.getsize(save_path) > 0:
                return True
            else:
                os.remove(save_path)
                return False
    except Exception: 
        pass
    return False

def download_page(page, out_dir, chapter_url=""):
    idx = page['index']
    raw_path = os.path.join(out_dir, f"raw_{idx}.jpg")
    
    if download_image(page['imageUrl'], raw_path, chapter_url):
        return raw_path
    return None

def process_merge_group(group_data, merge_idx, out_dir, target_width):
    current_height = 0
    images_to_paste = []
    
    for path, w, h in group_data:
        try:
            img = Image.open(path).convert("RGB")
            if img.width != target_width:
                new_h = int(img.height * (target_width / img.width))
                img = img.resize((target_width, new_h), Image.Resampling.LANCZOS)
            images_to_paste.append(img)
            current_height += img.height
        except Exception:
            continue
            
    if not images_to_paste:
        return None
        
    merged_img = Image.new('RGB', (target_width, current_height))
    y_offset = 0
    for im in images_to_paste:
        merged_img.paste(im, (0, y_offset))
        y_offset += im.height
        
    new_path = os.path.join(out_dir, f"merged_raw_{str(merge_idx).zfill(3)}.jpg")
    merged_img.save(new_path, format="JPEG", quality=95)
    
    for path, _, _ in group_data:
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
                
    return new_path

def merge_short_images(raw_paths, target_height=2200, max_workers=6):
    if not raw_paths: return []
    
    img_infos = []
    for path in raw_paths:
        try:
            with Image.open(path) as img:
                img_infos.append((path, img.width, img.height))
        except Exception:
            pass
            
    if not img_infos: return []
    
    groups = []
    current_group = []
    current_h = 0
    target_w = img_infos[0][1] 
    
    for info in img_infos:
        path, w, h = info
        est_h = int(h * (target_w / w)) if w != target_w else h
        
        current_group.append(info)
        current_h += est_h
        
        if current_h >= target_height:
            groups.append(current_group)
            current_group = []
            current_h = 0
            
    if current_group:
        groups.append(current_group)
        
    out_dir = os.path.dirname(raw_paths[0])
    merged_paths = []
    
    print(f"Mengeksekusi penggabungan {len(groups)} grup gambar secara paralel...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_idx = {
            executor.submit(process_merge_group, grp, idx+1, out_dir, target_w): idx+1
            for idx, grp in enumerate(groups)
        }
        
        results = {}
        for future in concurrent.futures.as_completed(future_to_idx):
            idx = future_to_idx[future]
            res_path = future.result()
            if res_path:
                results[idx] = res_path
                
    for i in sorted(results.keys()):
        merged_paths.append(results[i])
        
    return merged_paths

def smart_slice_image(image_path, target_height=1200, out_dir="output"):
    """
    Memotong gambar dengan Edge Detection & Morphological Dilation.
    Aman untuk teks/bubble karena huruf akan dilebur menjadi satu blok 
    agar tidak terpotong di tengah-tengah kalimat.
    """
    import cv2
    import numpy as np
    import os

    img = cv2.imread(image_path)
    if img is None:
        print(f"[Error] Tidak bisa membaca gambar {image_path}")
        return [image_path]

    height, width = img.shape[:2]
    
    if height <= target_height:
        return [image_path]

    # 1. Ubah ke Grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # 2. Deteksi Tepi (Canny) tanpa blur berlebih agar garis teks/panel tetap tajam
    edges = cv2.Canny(gray, 50, 150)
    
    # 3. KUNCI UTAMA: Morphological Dilation
    # Kita "melebarkan" garis tepi dengan kotak besar (30x30).
    # Efeknya: Huruf-huruf di dalam balon percakapan akan menyatu menjadi
    # satu blok putih yang solid. Algoritma TIDAK AKAN menganggap
    # spasi antar baris kalimat sebagai "ruang kosong".
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (30, 30))
    dilated = cv2.dilate(edges, kernel, iterations=1)
    
    # 4. Hitung kepadatan (density) garis per baris
    row_density = np.sum(dilated, axis=1) / 255.0
    
    sliced_paths = []
    y_start = 0
    part = 1
    
    base_name = os.path.splitext(os.path.basename(image_path))[0]
    os.makedirs(out_dir, exist_ok=True)

    while y_start < height:
        y_end = y_start + target_height
        
        if y_end >= height:
            y_end = height
            slice_img = img[y_start:y_end, :]
            slice_path = os.path.join(out_dir, f"{base_name}_part{part}.jpg")
            cv2.imwrite(slice_path, slice_img)
            sliced_paths.append(slice_path)
            break
            
        gap_size = 15 # Butuh area kosong secara vertikal minimal 15 piksel
        found_safe_cut = False
        
        # Toleransi dinamis: kita mulai dari 0 (harus benar-benar area kosong melompong).
        # Jika gak ketemu celah sama sekali, baru toleransi dinaikkan sedikit demi sedikit 
        # untuk memotong background/screentone tipis.
        tolerance = 0
        max_tolerance = width * 0.10 # Batas maksimal toleransi (10% dari lebar)
        
        while tolerance <= max_tolerance and not found_safe_cut:
            safe_rows = row_density <= tolerance
            
            # Cari celah aman ke ATAS dulu (sampai setengah dari target height)
            search_limit_up = max(y_start + int(target_height * 0.5), y_start + gap_size)
            for y in range(y_end, search_limit_up, -1):
                if np.all(safe_rows[y-gap_size : y]):
                    y_end = y - (gap_size // 2) # Potong tepat di tengah-tengah celah aman
                    found_safe_cut = True
                    break
            
            # Jika gagal mencari ke atas, cari ke BAWAH
            if not found_safe_cut:
                search_limit_down = min(y_start + int(target_height * 1.5), height - gap_size)
                for y in range(y_end, search_limit_down):
                    if np.all(safe_rows[y : y+gap_size]):
                        y_end = y + (gap_size // 2)
                        found_safe_cut = True
                        break
            
            # Jika masih belum ketemu area kosong, naikkan toleransinya (paksa cari celah di background)
            if not found_safe_cut:
                if tolerance == 0:
                    tolerance = width * 0.02
                else:
                    tolerance += width * 0.03

        if not found_safe_cut:
            print(f"[Warning] Area terlalu padat di {base_name}. Potong paksa di Y:{y_end}.")
    
        slice_img = img[y_start:y_end, :]
        slice_path = os.path.join(out_dir, f"{base_name}_part{part}.jpg")
        cv2.imwrite(slice_path, slice_img)
        sliced_paths.append(slice_path)
        
        y_start = y_end
        part += 1
        
    return sliced_paths
